//
//  RegisterViewController.swift
//  Medical_Inspire
//
//  Created by Inspire_User on 01/02/19.
//  Copyright © 2019 InspireInfotech. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class RegisterViewController: UIViewController {
    
    @IBOutlet weak var Emailtxt: UITextField!
    @IBOutlet weak var Passwardtxt: UITextField!
    @IBOutlet weak var conformpasstxt: UITextField!

    var ref : DatabaseReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        ref = Database.database().reference()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func singupbtn(_ sender: UIButton) {
  
        Auth.auth().createUser(withEmail: Emailtxt.text!, password: Passwardtxt.text!) { (user, error) in
            if error != nil{
            print("error")
            }
            else{
        print("registrationsuccessful")
                
                self.ref.child("Registration").childByAutoId().setValue(["Emailtxt":self.Emailtxt.text!,"Passwardtxt":self.Passwardtxt.text!," conformpasstxt":self.conformpasstxt.text!])
                
                let regView = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
self.navigationController?.pushViewController(regView!, animated: true)
                
            }
    }
}
}
