//
//  CheckinViewController.swift
//  Medical_Inspire
//
//  Created by APPLE on 23/05/18.
//  Copyright © 2018 InspireInfotech. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import MapKit
import CoreLocation

class CheckinViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate, CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource {
    

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var t1: UITextField! //NamePickerTextField
    @IBOutlet weak var checkInTextField: UITextField! //DatePickerTextField
    @IBOutlet weak var dataTable: UITableView!
    let locationManager = CLLocationManager()
    var latitude : String = ""
    var longitude : String = ""
    @IBOutlet weak var t3: UITextField! //WhomToMeet
    //var refCheckin: DatabaseReference!
    var pickerview = UIPickerView() //NamePicker
    let picker = UIDatePicker() //DatePicker
    let EmpName = ["Himanshu","Saad","Divya","Aldrin"]
    var ref: DatabaseReference!
    var checkinList = [CheckinModel]()
    
    @IBAction func TapGesture(_ sender: Any) {
        view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        t1.inputView = pickerview
        checkInTextField.inputView=picker
        pickerview.dataSource = self
        pickerview.delegate = self
        dataTable.delegate = self
        dataTable.dataSource = self
        ref = Database.database().reference().child("Check_In_Table")
        createDatePicker()
        //let locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        ref.observe(.childAdded, with: { (snapshot) in
            
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.checkinList.removeAll()
                
                //iterating through all the values
                for checkin in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let checkinObject = checkin.value as? [String: AnyObject]
                    let checkinLatitude = checkinObject?["latitude"]
                    let checkinLongitude = checkinObject?["longitude"]
                    let checkinName  = checkinObject?["Emp_name"]
                    let checkinDate  = checkinObject?["Date_Time"]
                    let checkinWtm = checkinObject?["Whom_To_Meet"]
                    
                    //creating artist object with model and fetched values
                    let checkin = CheckinModel(name: checkinName as! String?, date: checkinDate as! String?,lat: checkinLatitude as! String?,lon: checkinLongitude as! String?,  wtm: checkinWtm as! String?)
                    
                    //appending it to list
                    self.checkinList.append(checkin)
                }
                
                //reloading the tableview
                self.dataTable.reloadData()
            }
        })
        
        
}
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return checkinList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerTableViewCell
        
        //the artist object
        let checkin:CheckinModel
        
        //getting the artist of selected position
        checkin = checkinList[indexPath.row]
        
        //adding values to labels
        cell.nameLabel.text = checkin.name
        cell.dateLabel.text = checkin.date
        cell.lattitudeLabel.text = checkin.lat
        cell.longitudeLabel.text = checkin.lon
        cell.whomToMeetLabel.text = checkin.wtm
        
        //returning cell
        return cell
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[locations.count - 1]
        let center = location.coordinate
        let span = MKCoordinateSpan(latitudeDelta:28.5493, longitudeDelta:77.2514)
        let region = MKCoordinateRegion(center: center, span: span)
        mapView.setRegion(region, animated: true)
        mapView.showsUserLocation = true
        if location.horizontalAccuracy > 0 {
            
            self.locationManager.stopUpdatingLocation()
            
            print("longitude = \(location.coordinate.longitude), latitude = \(location.coordinate.latitude)")
            
            latitude = String(location.coordinate.latitude)
            longitude = String(location.coordinate.longitude)
            
            
            print(latitude, longitude)
            
            
        }
    }
    
    
    func createDatePicker(){
        //toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        //Done Button
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([done], animated: false)
        checkInTextField.inputAccessoryView = toolbar
        checkInTextField.inputView = picker
    }
    
    @objc func donePressed(){
        //format Date
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium
        let dateString = formatter.string(from: picker.date)
        
        checkInTextField.text = "\(dateString)"
        self.view.endEditing(true)
    }

   
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return EmpName.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return EmpName[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.t1.text = self.EmpName[row]
    }
    
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func CheckinBtn(_ sender: UIButton) {
        //self.ref.child("Check_In").childByAutoId().setValue(["Emp_name":t1.text,"Date_Time":checkInTextField.text,"Location":t2.text,"Whom_To_Meet":t3.text])
        //sendDataToDataBase(latitude: latitude, longitude: longitude)
        
        
        
        self.ref.child("Check_In_Table").childByAutoId().setValue(["latitude" : latitude, "longitude" : longitude, "Emp_name":t1.text!, "Date_Time":checkInTextField.text!, "Whom_To_Meet":t3.text!])
         myAlert("success","successfully registered")
        self.clean()
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    
    func myAlert(_ myTitle:String, _ myMessage:String){
        
        let alert=UIAlertController(title:myTitle, message:myMessage, preferredStyle:.actionSheet)
        let ok=UIAlertAction(title:"ok", style:.default,handler:nil)
        alert.addAction(ok)
        self.present(alert, animated:true, completion:nil)
    }
    func clean()
    {
        t1.text = " "
        checkInTextField.text = " "
        //text = " "
        t3.text = " "
    }

   /* func sendDataToDataBase(latitude : String, longitude : String) {
        
        //SVProgressHUD.setDefaultMaskType(.gradient)
        //SVProgressHUD.show(withStatus: "Checking In")
        //let ref = Database.database().reference()
        /*let postsReference = ref.child("Check_In_Data")
        let newPostId = postsReference.childByAutoId().key
        let newPostReference = postsReference.child(newPostId)
        newPostReference.setValue(["latitude" : latitude, "longitude" : longitude, "employeeName" : t1.text!, "CheckInDate&Time" : checkInTextField.text!,"Whom_To_Meet":t3.text])*/
        
    self.ref.child("Check_In_Table").childByAutoId().setValue(["latitude" : latitude, "longitude" : longitude, "Emp_name":t1.text, "Date_Time":checkInTextField.text, "Whom_To_Meet":t3.text])
        
        //(["latitude" : latitude, "longitude" : longitude, "employeeName" : t1.text!, "CheckInDate&Time" : checkInTextField.text!,"Whom_To_Meet":t3.text], withCompletionBlock: { (error, ref) in
            /*if error != nil {
                SVProgressHUD.showError(withStatus: error!.localizedDescription)
                return
            }*/
            //SVProgressHUD.showSuccess(withStatus: "Success")
            //SVProgressHUD.dismiss(withDelay: 0.5)
           // self.clean()
            // Pass it in Firebase
            
            //            let user = Auth.auth().currentUser
            //            ref = Database.database().reference()
            //            self.ref.child("users").child((user?.uid)!).setValue(["latitude": latitude, "longitude": longitude])
            
}*/
    
/*func clean() {
        checkInTextField.text = ""
        t1.text = ""
    }

*/
    
  

}
