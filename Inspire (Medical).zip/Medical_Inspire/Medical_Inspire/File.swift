//
//  File.swift
//  Medical_Inspire
//
//  Created by Inspire_User on 01/02/19.
//  Copyright © 2019 InspireInfotech. All rights reserved.
//

import Foundation
class CheckinModel{
    var name:String?
    var date:String?
    var lat:String?
    var lon:String?
    var wtm:String?
    
    init(name:String? ,date:String? ,lat:String? ,lon:String? ,wtm:String?)
    {
        self.name = name
        self.date = date
        self.lat = lat
        self.lon = lon
        self.wtm = wtm
    }
    
}
