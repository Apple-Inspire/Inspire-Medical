//
//  LoginViewController.swift
//  Medical_Inspire
//
//  Created by Inspire on 30/01/19.
//  Copyright © 2019 InspireInfotech. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class LoginViewController: UIViewController {

    var reff : DatabaseReference!
    
    @IBOutlet weak var LogEmail: UITextField!
    @IBOutlet weak var LogPass: UITextField!
    var database = Firebase.Database();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reff = Database.database().reference()
        
        // Do any additional setup after loading the view.
    }
    
   override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginAction(_ sender: UIButton) {
        /*
        Auth.auth().signIn(withEmail: LogEmail.text!, password: LogPass.text!) { (user, error) in
            if error != nil{
                print(error!)
        }
         */
        print(LogEmail.text!)
        print(LogPass.text!)
            Auth.auth().signIn(withEmail: LogEmail.text!, password: LogPass.text!) { (user, error) in
                if error != nil{
                    print(error!)
                }
                    
            else
            {
        print("Login Successful")
                let profileView = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
                self.navigationController?.pushViewController(profileView!, animated: true)
}

        }
}
}

