//
//  ViewController.swift
//  Medical_Inspire
//
//  Created by APPLE on 23/05/18.
//  Copyright © 2018 InspireInfotech. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    let Medical = ["Checkin Employe","Checkout Employe","Website","Contact Us"]
    var myIndex = 0
    @IBOutlet weak var Table: UITableView!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate = self
        Table.dataSource = self
        Table.isHidden = true
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Medical.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for : indexPath)
        cell.textLabel?.text = Medical [indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex=indexPath.row
        if myIndex == 0{
            
            performSegue(withIdentifier: "Checkin", sender: self)
        }
        
        if myIndex==1 {
            
            performSegue(withIdentifier: "Checkout", sender: self)
        }
        
        if myIndex==2 {
            
           
            let url = NSURL(string: "http://www.inspireinfo.com")
            UIApplication.shared.openURL(url! as URL)
        }
        if myIndex==3 {
            
            performSegue(withIdentifier: "Contact", sender: self)
        }
    }
    @IBAction func SideButton(_ sender: UIBarButtonItem) {
          if Table.isHidden==true {
            Table.isHidden=false
        }
        else{
            Table.isHidden = true
        }
    }
    
    
    @IBAction func SideButton1(_ sender: Any) {
        
        if Table.isHidden==true {
            Table.isHidden=false
        }
        else{
            Table.isHidden = true
        }
    }
    
    @IBAction func logout(_ sender: UIBarButtonItem) {

        print("Logout Successful")
            let profileView = self.storyboard?.instantiateViewController(withIdentifier: "homeViewController") as?homeViewController
            self.navigationController?.pushViewController(profileView!, animated: true)
        }
    }

