//
//  CheckoutViewController.swift
//  Medical_Inspire
//
//  Created by APPLE on 23/05/18.
//  Copyright © 2018 InspireInfotech. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import MapKit
import CoreLocation

class CheckoutViewController: UIViewController, UITextFieldDelegate, UIPickerViewDataSource, UIPickerViewDelegate,CLLocationManagerDelegate {
    @IBOutlet weak var t1: UITextField!
    
    var pickerview = UIPickerView()
    let EmpName = ["Himanshu","Saad","Divya","Aldrin"]
    
    @IBOutlet weak var checkInTextField: UITextField!
    
    
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    var latitude : String = ""
    var longitude : String = ""
    
    var picker = UIDatePicker()
    var ref:DatabaseReference!
    override func viewDidLoad() {
        super.viewDidLoad()
        t1.inputView = pickerview
        pickerview.dataSource = self
        pickerview.delegate = self
        createDatePicker()
        ref = Database.database().reference()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()

        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func TapGesture(_ sender: Any) {
        view.endEditing(true)
    }
    func createDatePicker(){
        //toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        //Done Button
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([done], animated: false)
        checkInTextField.inputAccessoryView = toolbar
        checkInTextField.inputView = picker
    }
    
    @objc func donePressed(){
        //format Date
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium
        let dateString = formatter.string(from: picker.date)
        
        checkInTextField.text = "\(dateString)"
        self.view.endEditing(true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return EmpName.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return EmpName[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.t1.text = self.EmpName[row]
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[locations.count - 1]
        let center = location.coordinate
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: center, span: span)
        mapView.setRegion(region, animated: true)
        mapView.showsUserLocation = true
        if location.horizontalAccuracy > 0 {
            
            self.locationManager.stopUpdatingLocation()
            
            print("longitude = \(location.coordinate.longitude), latitude = \(location.coordinate.latitude)")
            
            latitude = String(location.coordinate.latitude)
            longitude = String(location.coordinate.longitude)
            
            
            print(latitude, longitude)
            
            
        }
    }
    
    @IBAction func CheckoutBtn(_ sender: Any) {
        
        self.ref.child("Check_Out_Table").childByAutoId().setValue(["latitude" : latitude, "longitude" : longitude, "Emp_name":t1.text!, "Date_Time":checkInTextField.text!])
        myAlert("success","successfully registered")
        self.clean()
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    func myAlert(_ myTitle:String, _ myMessage:String){
        
        let alert=UIAlertController(title:myTitle, message:myMessage, preferredStyle:.actionSheet)
        let ok=UIAlertAction(title:"ok", style:.default,handler:nil)
        alert.addAction(ok)
        self.present(alert, animated:true, completion:nil)
    }
    func clean()
    {
        t1.text = " "
        checkInTextField.text = " "
        //text = " "

    }
    
}
